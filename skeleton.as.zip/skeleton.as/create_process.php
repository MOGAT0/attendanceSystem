<?php 
    include ("conn.php");
    if(isset($_POST['create_acc'])){
        $stud_id = $_POST['stud_id'];
        $stud_email = $_POST['stud_email'];
        $stud_last = $_POST['stud_last'];
        $stud_first = $_POST['stud_first'];
        $stud_middle = $_POST['stud_middle'];
        $stud_course = $_POST['course'];
        $stud_pass = $_POST['stud_pass'];

        $insert =   $insert = "INSERT INTO attendance (student_id, email, lastname, firstname, middlename, course, password) 
               VALUES ('$stud_id','$stud_email', '$stud_last', '$stud_first', '$stud_middle', '$stud_course', '$stud_pass')";
         $insert_data = mysqli_query($conn, $insert);


         if($insert_data==true){
            ?> 
            <script>
                alert ("The Data is successfully inserted");
                windows.location.href="dashboard.php";
            </script>
            
            <?php
         }

         
     }
  

?>