<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Document</title>
</head>
<body>
    <nav>
        <h1>
            ATTENDIFY
        </h1>
    </nav>
    <div class="main">
        <div class="desc">
            <h1 class="heading">WELCOME TO <span>ATTENDIFY</span></h1>
            <p class="txt">The ultimate platform for effortless student attendance tracking</p>
            <button onclick="loginPage()">Login &#8594;</button>
        </div>
        <div class="image">
            <img src="assets/homeLogo.png" alt="stock image">
        </div>
    </div>
    <center><a href="#banner" class="arrowdown">&#11033;</a></center>
    
    <div class="banner" id="banner">
        <br><br><br><br><center><h1>CREATORS</h1></center>
        <div class="slider" style="--quantity: 6">
            <div class="item" style="--position: 1"><img src="assets/eli.jpg" alt="Elizabeth"></div>
            <div class="item" style="--position: 2"><img src="assets/quintio.jpg" alt="Quinto"></div>
            <div class="item" style="--position: 3"><img src="assets/herold.jpg" alt="Herold"></div>
            <div class="item" style="--position: 4"><img src="assets/pearl.jpg" alt="Pearl"></div>
            <div class="item" style="--position: 5"><img src="assets/sam.jpg" alt="Sam"></div>
            <div class="item" style="--position: 6"><img src="" alt="Marga"></div>
    </div>
</body>
</html>

<script>
    function loginPage(){
        window.location.href = "login.php";
    }
</script>